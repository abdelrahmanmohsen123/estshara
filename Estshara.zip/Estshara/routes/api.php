<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\ConsultantController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

// Route::middleware('auth:api')->get('/user', function (Request $request) {
//     return $request->user();
// });

Route::group(['middleware' => 'api','prefix' => 'auth'], function ($router) {
    Route::post('/login', [ConsultantController::class, 'login']);
    Route::post('/register', [ConsultantController::class, 'register']);
    Route::post('/logout', [ConsultantController::class, 'logout']);
    Route::get('/user-profile', [ConsultantController::class, 'userProfile']);    
});
Route::group(['middleware' => 'api'], function ($router) {
    Route::get('/terms-conditions', [ConsultantController::class, 'termsConditions']);  
    Route::get('/aboutUs', [ConsultantController::class, 'aboutUs']);
    Route::post('/contactUs', [ConsultantController::class, 'contactUs']);       
});
