<?php

namespace App\Http\Resources;

use Illuminate\Http\Resources\Json\JsonResource;

class UserResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array|\Illuminate\Contracts\Support\Arrayable|\JsonSerializable
     */
    public function toArray($request)
    {
        $data = [
            'id'                => $this->id,
            'type'              => $this->type == 0 ? 'مستخدم' : 'مستشار',
            'name'              => $this->name,
            'email'             => $this->email,
            'firebase_token'    => $this->firebase_token,
            'phone'             => $this->phone ?? '',
            'gender'            => $this->gender ?? '',
            'image'             => asset('/') . $this->image ?? '',
            'birth_of_year'     => $this->birth_of_year ?? '',
        ];
        if ($this->type == 1) {
            $data['additional_phone'] =  $this->additional_phone ?? '';
            $data['years_of_experience'] = $this->years_of_experience ?? '';
            $data['education'] = $this->education ?? '';
            $data['experience'] = $this->experience ?? '';
            $data['education_certificate'] = asset('/') . $this->education_certificate ?? '';
            $data['experience_certificate'] = asset('/') . $this->experience_certificate ?? '';
            $data['subcatgory_id'] = $this->subcatgory_id ?? '';
        }
        $data['token'] = $this->token;
        return $data;
    }
}
