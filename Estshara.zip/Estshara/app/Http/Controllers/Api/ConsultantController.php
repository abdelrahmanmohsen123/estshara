<?php

namespace App\Http\Controllers\Api;

use Auth;
use App\Models\User;
use App\Models\Contact;
use App\Models\Setting;
use App\Traits\GeneralTrait;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Resources\UserResource;
use Illuminate\Support\Facades\Validator;

class ConsultantController extends Controller
{
    use GeneralTrait;
    public function __construct() {
        $this->middleware(['api', 'jwt.verify'], ['except' => ['login', 'register']]);
    }

    public function login(Request $request){

    	$validator = Validator::make($request->all(), [
            'email'    => 'required|email',
            'password' => 'required|string|min:6',
        ]);
        if ($validator->fails()) {
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }

        if ($token = Auth::guard('api')->attempt(['email' => $request->email, 'password' => $request->password])) 
        {
            $user = Auth::guard('api')->user();
            $input['firebase_token'] = $request->firebase_token;
            $user->update($input);
            $user->token = $token;
            $user = new UserResource($user);
            return $this->returnData('user', $user);
        }
        else
        {
            return $this->returnError('E001', 'بيانات الدخول غير صحيحة');
        }
    }
    

    public function register(Request $request) 
    {
        $validator = Validator::make($request->all(), [
            'email' => 'required|string|email|max:100|unique:users,email',
            'password' => 'required|string|confirmed',
        ]);
        if($validator->fails()){
            $code = $this->returnCodeAccordingToInput($validator);
            return $this->returnValidationError($code, $validator);
        }
        try
        {
            $image = '';
            if ($request->has('image')) {
                $image = uploadImage('consultants', $request->image);
            }
            $education_certificate = '';
            if ($request->has('education_certificate')) {
                $education_certificate = uploadImage('consultants', $request->education_certificate);
            }
            $experience_certificate = '';
            if ($request->has('experience_certificate')) {
                $experience_certificate = uploadImage('consultants', $request->experience_certificate);
            }
            
            $user = User::create([
                'type'                    => 1,
                'name'                    => $request->name,
                'email'                   => $request->email,
                'password'                => bcrypt($request->password),
                'phone'                   => $request->phone,
                'additional_phone'        => $request->additional_phone,
                'birth_of_year'           => $request->birth_of_year,
                'gender'                  => $request->gender,
                'firebase_token'          => $request->firebase_token,
                'years_of_experience'     => $request->years_of_experience,
                'education'               => $request->education,
                'experience'              => $request->experience,
                'image'                   => $image,
                'subcatgory_id'           => $request->subcatgory_id,
                'education_certificate'   => $education_certificate,
                'experience_certificate'  => $experience_certificate,
            ]);
            return $this->returnSuccessMessage('تم انشاء الحساب بنجاح');
        }
        catch (\Exception $e) {
            return $this->returnError(404, $e->getMessage());
        }
        
    }
    

    public function logout() 
    {
        auth()->logout();
        return $this->returnSuccessMessage('تم تسجيل الخروج بنجاح');
    }
    

    public function userProfile() 
    {
        return response()->json(auth()->user());
    }

    public function termsConditions() 
    {
        $termsConditions = Setting::first()->terms_conditions ?? '';
        return $this->returnData('termsConditions', $termsConditions);
    }
    public function aboutUs() 
    {
        $aboutUs = Setting::first()->about_us ?? '';
        return $this->returnData('aboutUs', $aboutUs);
    }
    public function contactUs(Request $request) 
    {
        try
        {
            $validator = Validator::make($request->all(), [
                'name'     => 'required',
                'email'    => 'required|email',
                'message'  => 'required',
            ]);
            if ($validator->fails()) {
                $code = $this->returnCodeAccordingToInput($validator);
                return $this->returnValidationError($code, $validator);
            }
            Contact::create([
                'name'         => $request->name,
                'email'        => $request->email,
                'message'      => $request->message,
            ]);
            return $this->returnSuccessMessage('تم ارسال الرسالة بنجاح');
        }
        catch (\Exception $e) {
            return $this->returnError(404, $e->getMessage());
        }
    }
}
